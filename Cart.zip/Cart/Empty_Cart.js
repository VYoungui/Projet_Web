// Récupération du bouton "Keep shopping"
const keepShoppingButton = document.querySelector('.keep-shopping-button');

const container = document.getElementById('container');
// Ajout d'un écouteur d'événement sur le clic du bouton
keepShoppingButton.addEventListener('click', () => {
    // Redirection vers la page d'accueil
    window.location.href = "https://www.example.com";
});

const cartMessage = document.getElementById('empty-cart-message');
// Récupération du tableau d'articles
const articleTable = document.querySelector('table');

// Récupération du compteur d'articles
const articleCount = document.getElementById('article-count');
const buy = document.getElementById('buy');

// Initialisation du compteur d'articles
articleCount.innerText = articleTable.rows.length - 1; // Soustrait 1 pour exclure l'en-tête du tableau

var itemCount = articleCount.innerText;
// Mise à jour de la variable de comptage
articleCount.innerText = itemCount;

// Vérification de la valeur de la variable de comptage
if (itemCount > 0) {
    cartMessage.remove();
    container.remove();
};


let total = 0;
const cells = document.querySelectorAll('.price'); // Sélectionne toutes les cellules avec la classe CSS "prix"
cells.forEach(cell => {
    const price = parseFloat(cell.innerText.replace(/[^0-9.-]+/g, '')); // Récupère le prix de la cellule et le convertit en nombre
    if (!isNaN(price)) { // Vérifie si le prix est un nombre valide
        total += price; // Ajoute le prix au total
    }
});
const totalElement = document.getElementById('total'); // Récupère l'élément HTML avec l'ID "total-prix"
totalElement.innerText = total.toFixed(2);


if (itemCount === '0' || total === 0) {
    const buyElement = document.getElementById('buy');
    buyElement.remove();
    articleTable.remove();
}